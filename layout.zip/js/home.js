$('.btn-pt').hover(function() {
  $(this).toggleClass('bg-yellow', true);
});

$('.btn-dh').hover(function() {
  $(this).toggleClass('bg-orange', true);
});